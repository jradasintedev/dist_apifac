<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/api/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::60pUnGy2GRrc87FM',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/listadinamica/getListasDinamicasFull' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9xLUMelec7UmwgZR',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/cargo/getCargos' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::f4nYqvBaAQRXJmEo',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/cargos/getCargosId' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EGq7OImr8PH8izey',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/cargo/crearCargos' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::681TdXSJv4qwgWJP',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/cargo/actualizarCargos' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::a05616trEq0otY86',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/cargo/getDetalleCargos' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8CXyQO78dxDCcfzv',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/cargo/getCargosFull' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::S3p21GDSIe29A8hn',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/cargo/getCargosGradosByCargoId' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hCdko31L77RBrFYU',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/cargo/crearCargosGrados' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::osvLzX4QcBl1OubA',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/cargo/actualizarCargosGrados' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::s0c0y9AwrGgXcjI5',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/cargo/getCargosConfiguracionByCargoGradoId' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::adHxwyPN2MbcdabE',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/cargo/crearCargosConfiguracion' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::k1AM0h2hw5wMjqqy',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/cargo/actualizarCargosConfiguracion' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aBHrvY0bicx4t690',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/cargo/getCargosExperienciasById' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qwPfEXemqS5HIoVZ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/cargo/crearCargosExperiencias' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jTV8XY0UZODpNI6l',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/cargo/actualizarCargosExperiencias' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6XWHlMKbKqKNYHYB',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/cargo/getUbicacionCargosId' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iJTYscRFDRV0lFYC',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/cargo/crearUbicacionCargos' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lzhajmKKQtj9NUV7',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/cargo/actualizarUbicacionCargos' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DB24Rsa560HUesCM',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/area/getAreasFull' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Owb8ZbRInp2xQvC3',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/area/getAreas' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zCNwGSToZ0aG9iG5',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/area/crearAreas' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7VpbBILTZuPUjd4N',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/area/actualizarAreas' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FZlm5UcTwrMrbWOs',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/cuerpo/getCuerposFull' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Q6V9XmK0g7WWzwiy',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/cuerpo/getCuerpos' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3QPoHJns5QygdbUh',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/cuerpo/crearCuerpos' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YxtUYQkV1DgG4wQv',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/cuerpo/actualizarCuerpos' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oKaWYP7xw6LKLFmL',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/especialidad/getEspecialidadesFull' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QTfioijcY3NCqIo6',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/especialidad/getEspecialidades' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::E7LbxALj9KVJUNAV',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/especialidad/crearEspecialidades' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HcbL9XuiVyCPx0zq',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/especialidad/actualizarEspecialidades' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::McnNB7qiKUZMHRlp',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/grado/getGradosFull' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OBhTMqffnxARZGXB',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/grado/getGrados' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZQxWkS3r7sTYCkKv',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/grado/crearGrados' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FfW77JQrsRivL46F',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/grado/actualizarGrados' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tr17lV9sCZtTjnnH',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/grado/getDetalleGrados' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8x0OvfXQruuHM3eL',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/listadinamica/getNombresListas' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dk6kgJ2VK9pk7tLW',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/listadinamica/crearNombresListas' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wjPkv81pkkrNXkgc',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/listadinamica/actualizarNombresListas' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ub5hIRJb3OSKObOr',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/listadinamica/getListasDinamicas' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Thlu5Vsfj2CV8njA',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/listadinamica/crearListasDinamicas' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::acqjWDoPQVCUfSa9',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/listadinamica/actualizarListasDinamicas' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::N70VSUAyXmuUvutj',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/listadinamica/getNombresListasFull' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::G5gU3R52TjX0sC1o',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/menu/getMenus' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7ceaHib4stClA7OG',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/menu/crearMenus' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TlDAIkJvOQfnnviV',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/menu/actualizarMenus' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fmgI4rIW1TmiQmA6',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/perfil/getPerfiles' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::80QW5qM4DAwq67rf',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/perfil/crearPerfiles' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aTfz2IvuGK9qaltE',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/perfil/actualizarPerfiles' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tPerGLRAH0jRk7uJ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/perfil/getPerfilesFull' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YYXKsjlh316TwKHn',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/perfilusuario/getPerfilesUsuarios' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vBaPnHkLMidwqEGN',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/perfilusuario/crearPerfilesUsuario' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KpCTHCRS3KyVAKb8',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/perfilusuario/actualizarPerfilesUsuarios' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yB3VjmgUe452Dz4X',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/requerimiento/getRequerimientos' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::F0mYUgUU3nxeySV9',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/requerimiento/crearRequerimientos' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::25Gg7ol4JnzgamCO',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/requerimiento/actualizarRequerimientos' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SXPpYA6T8uDnAON4',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/rutacarrera/getRutaCarrera' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GlYu5XbSkBRWxAaX',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/rutacarrera/crearRutaCarrera' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zFISJWb58raEAFDy',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/rutacarrera/actualizarRutaCarrera' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qgy534RkPqZuagdU',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/rutacarrera/crearLineasCargos' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::t9eS5e4bSpaTuEkO',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/rutacarrera/actualizarLineasCargos' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::51fTI4NXt9IFcid8',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/rutacarrera/getLineasCargos' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lj1FcfjWKKnBDEw4',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/rutacarrera/getRutas' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BFMpqxDqkhbVVLuE',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/rutacarrera/crearRutas' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vQwVHbcExF60qX8a',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/rutacarrera/actualizarRutas' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rVqjhF2fgDoBgCZX',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/rutacarrera/getRutasByRutaCarrera' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OoJMzjIb6m5quXwO',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/rutacarrera/getCargosByRutas' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EPXiX7CgXnoMW2uU',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/rutacarrera/getGradosByEspecialidad' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bWO1Ucw3KJ9S47So',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/rutacarrera/getGradosDetalleByEspecialidad' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EM8MmIeFkQOYLaVt',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/rutacarrera/getGradosDetalleCargo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZUzHXZEtz2DhfDQJ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/rutacarrera/getGradosDetalleRequerimiento' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2LWJJ0AlLCtChxaz',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/rutacarrera/getCuerposByCategoria' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iWkbs24llcgUTVW5',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/rutacarrera/getEspecialidadesByCategoriaCuerpo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LCwKIaWuKGqDVMWe',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/rutacarrera/getAreasByCategoriaEspecialidad' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HHuaHTGjwUfOnO1G',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/rutacarrera/getDetalleCargoRutaCarrera' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uSbVVvSBoyrH4MUQ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/rutacarrera/getCuerposEspecialidadesAreasRutaCarrera' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zkib3TEsnnEROgPe',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/rutacarrera/getEspecialidadesRutas' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8AONqRSq2oUCGlmR',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/rutacarrera/getRutasFull' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rzBSNYm1Jd4hOYPm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/rutacarrera/getRutaCarreraActivos' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0hKEYxuD9VhaFXc3',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/rol/getRoles' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yz8HGAxK9cxVarek',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/rol/crearRoles' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iShrV9JhM1dtQJPL',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/rol/actualizarRoles' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uYwunL0yb5BqvJYE',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/rol/crearRolPrivilegios' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hsi6KcirQBmx8T3p',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/rol/actualizarRolPrivilegios' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WMVv9H6aCU4Zt94K',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/rol/getRolPrivilegiosById' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SEw2BTVPK9qtj7e3',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/rol/getRolesActivos' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5JO1PlE75zQeYKg7',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/rol/getModulos' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ibbAk9gKHSpk4pCv',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/usuario/getUsuariosFull' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IJLJuB3tc2ohO4Wx',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/usuario/getUsuarios' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ehR31itZIEaFaYvm',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/usuario/crearUsuarios' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gTKXFh2p6IhyOlEg',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/usuario/actualizarUsuarios' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::797WeWR8JEkgtkXZ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/usuario/crearUsuarioRol' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rJedlermaexZFCfW',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/usuario/actualizarUsuarioRol' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yEuCKsb3sFwMpMV6',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/usuario/getUsuariosRolesById' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GHAIrvp4lFVg4GmC',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/usuario/getRolPrivilegiosPantalla' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::x6T8b4hlz8ce6Pnk',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/usuariomenu/crearUsuarioMenu' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oBApDYepdQpFORWc',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/usuariomenu/actualizarUsuarioMenu' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qcgKMdnwm8V46qkG',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/usuariomenu/crearAsignarMenus' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OKV4oBULshHOxnlT',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/usuariomenu/actualizarAsignarMenus' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lwC9EanczfLmh8mW',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rDMEaaOfeB2TNerU',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
    ),
    3 => 
    array (
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::60pUnGy2GRrc87FM' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\UsuarioController@login',
        'controller' => 'App\\Http\\Controllers\\UsuarioController@login',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::60pUnGy2GRrc87FM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::9xLUMelec7UmwgZR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/listadinamica/getListasDinamicasFull',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\ListaDinamicaController@getListasDinamicasFull',
        'controller' => 'App\\Http\\Controllers\\ListaDinamicaController@getListasDinamicasFull',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::9xLUMelec7UmwgZR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::f4nYqvBaAQRXJmEo' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/cargo/getCargos',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\CargoController@getCargos',
        'controller' => 'App\\Http\\Controllers\\CargoController@getCargos',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::f4nYqvBaAQRXJmEo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::EGq7OImr8PH8izey' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/cargos/getCargosId',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\CargoController@getCargosId',
        'controller' => 'App\\Http\\Controllers\\CargoController@getCargosId',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::EGq7OImr8PH8izey',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::681TdXSJv4qwgWJP' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/cargo/crearCargos',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\CargoController@crearCargos',
        'controller' => 'App\\Http\\Controllers\\CargoController@crearCargos',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::681TdXSJv4qwgWJP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::a05616trEq0otY86' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/cargo/actualizarCargos',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\CargoController@actualizarCargos',
        'controller' => 'App\\Http\\Controllers\\CargoController@actualizarCargos',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::a05616trEq0otY86',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::8CXyQO78dxDCcfzv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/cargo/getDetalleCargos',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\CargoController@getDetalleCargos',
        'controller' => 'App\\Http\\Controllers\\CargoController@getDetalleCargos',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::8CXyQO78dxDCcfzv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::S3p21GDSIe29A8hn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/cargo/getCargosFull',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\CargoController@getCargosFull',
        'controller' => 'App\\Http\\Controllers\\CargoController@getCargosFull',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::S3p21GDSIe29A8hn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::hCdko31L77RBrFYU' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/cargo/getCargosGradosByCargoId',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\CargoController@getCargosGradosByCargoId',
        'controller' => 'App\\Http\\Controllers\\CargoController@getCargosGradosByCargoId',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::hCdko31L77RBrFYU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::osvLzX4QcBl1OubA' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/cargo/crearCargosGrados',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\CargoController@crearCargosGrados',
        'controller' => 'App\\Http\\Controllers\\CargoController@crearCargosGrados',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::osvLzX4QcBl1OubA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::s0c0y9AwrGgXcjI5' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/cargo/actualizarCargosGrados',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\CargoController@actualizarCargosGrados',
        'controller' => 'App\\Http\\Controllers\\CargoController@actualizarCargosGrados',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::s0c0y9AwrGgXcjI5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::adHxwyPN2MbcdabE' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/cargo/getCargosConfiguracionByCargoGradoId',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\CargoController@getCargosConfiguracionByCargoGradoId',
        'controller' => 'App\\Http\\Controllers\\CargoController@getCargosConfiguracionByCargoGradoId',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::adHxwyPN2MbcdabE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::k1AM0h2hw5wMjqqy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/cargo/crearCargosConfiguracion',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\CargoController@crearCargosConfiguracion',
        'controller' => 'App\\Http\\Controllers\\CargoController@crearCargosConfiguracion',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::k1AM0h2hw5wMjqqy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::aBHrvY0bicx4t690' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/cargo/actualizarCargosConfiguracion',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\CargoController@actualizarCargosConfiguracion',
        'controller' => 'App\\Http\\Controllers\\CargoController@actualizarCargosConfiguracion',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::aBHrvY0bicx4t690',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::qwPfEXemqS5HIoVZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/cargo/getCargosExperienciasById',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\CargoController@getCargosExperienciasById',
        'controller' => 'App\\Http\\Controllers\\CargoController@getCargosExperienciasById',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::qwPfEXemqS5HIoVZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::jTV8XY0UZODpNI6l' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/cargo/crearCargosExperiencias',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\CargoController@crearCargosExperiencias',
        'controller' => 'App\\Http\\Controllers\\CargoController@crearCargosExperiencias',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::jTV8XY0UZODpNI6l',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::6XWHlMKbKqKNYHYB' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/cargo/actualizarCargosExperiencias',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\CargoController@actualizarCargosExperiencias',
        'controller' => 'App\\Http\\Controllers\\CargoController@actualizarCargosExperiencias',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::6XWHlMKbKqKNYHYB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::iJTYscRFDRV0lFYC' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/cargo/getUbicacionCargosId',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\CargoController@getUbicacionCargosId',
        'controller' => 'App\\Http\\Controllers\\CargoController@getUbicacionCargosId',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::iJTYscRFDRV0lFYC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::lzhajmKKQtj9NUV7' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/cargo/crearUbicacionCargos',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\CargoController@crearUbicacionCargos',
        'controller' => 'App\\Http\\Controllers\\CargoController@crearUbicacionCargos',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::lzhajmKKQtj9NUV7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::DB24Rsa560HUesCM' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/cargo/actualizarUbicacionCargos',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\CargoController@actualizarUbicacionCargos',
        'controller' => 'App\\Http\\Controllers\\CargoController@actualizarUbicacionCargos',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::DB24Rsa560HUesCM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Owb8ZbRInp2xQvC3' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/area/getAreasFull',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\AreaController@getAreasFull',
        'controller' => 'App\\Http\\Controllers\\AreaController@getAreasFull',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::Owb8ZbRInp2xQvC3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::zCNwGSToZ0aG9iG5' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/area/getAreas',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\AreaController@getAreas',
        'controller' => 'App\\Http\\Controllers\\AreaController@getAreas',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::zCNwGSToZ0aG9iG5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::7VpbBILTZuPUjd4N' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/area/crearAreas',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\AreaController@crearAreas',
        'controller' => 'App\\Http\\Controllers\\AreaController@crearAreas',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::7VpbBILTZuPUjd4N',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::FZlm5UcTwrMrbWOs' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/area/actualizarAreas',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\AreaController@actualizarAreas',
        'controller' => 'App\\Http\\Controllers\\AreaController@actualizarAreas',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::FZlm5UcTwrMrbWOs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Q6V9XmK0g7WWzwiy' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/cuerpo/getCuerposFull',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\CuerpoController@getCuerposFull',
        'controller' => 'App\\Http\\Controllers\\CuerpoController@getCuerposFull',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::Q6V9XmK0g7WWzwiy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::3QPoHJns5QygdbUh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/cuerpo/getCuerpos',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\CuerpoController@getCuerpos',
        'controller' => 'App\\Http\\Controllers\\CuerpoController@getCuerpos',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::3QPoHJns5QygdbUh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::YxtUYQkV1DgG4wQv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/cuerpo/crearCuerpos',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\CuerpoController@crearCuerpos',
        'controller' => 'App\\Http\\Controllers\\CuerpoController@crearCuerpos',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::YxtUYQkV1DgG4wQv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::oKaWYP7xw6LKLFmL' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/cuerpo/actualizarCuerpos',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\CuerpoController@actualizarCuerpos',
        'controller' => 'App\\Http\\Controllers\\CuerpoController@actualizarCuerpos',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::oKaWYP7xw6LKLFmL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::QTfioijcY3NCqIo6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/especialidad/getEspecialidadesFull',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\EspecialidadController@getEspecialidadesFull',
        'controller' => 'App\\Http\\Controllers\\EspecialidadController@getEspecialidadesFull',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::QTfioijcY3NCqIo6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::E7LbxALj9KVJUNAV' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/especialidad/getEspecialidades',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\EspecialidadController@getEspecialidades',
        'controller' => 'App\\Http\\Controllers\\EspecialidadController@getEspecialidades',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::E7LbxALj9KVJUNAV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::HcbL9XuiVyCPx0zq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/especialidad/crearEspecialidades',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\EspecialidadController@crearEspecialidades',
        'controller' => 'App\\Http\\Controllers\\EspecialidadController@crearEspecialidades',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::HcbL9XuiVyCPx0zq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::McnNB7qiKUZMHRlp' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/especialidad/actualizarEspecialidades',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\EspecialidadController@actualizarEspecialidades',
        'controller' => 'App\\Http\\Controllers\\EspecialidadController@actualizarEspecialidades',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::McnNB7qiKUZMHRlp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::OBhTMqffnxARZGXB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/grado/getGradosFull',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\GradoController@getGradosFull',
        'controller' => 'App\\Http\\Controllers\\GradoController@getGradosFull',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::OBhTMqffnxARZGXB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ZQxWkS3r7sTYCkKv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/grado/getGrados',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\GradoController@getGrados',
        'controller' => 'App\\Http\\Controllers\\GradoController@getGrados',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::ZQxWkS3r7sTYCkKv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::FfW77JQrsRivL46F' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/grado/crearGrados',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\GradoController@crearGrados',
        'controller' => 'App\\Http\\Controllers\\GradoController@crearGrados',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::FfW77JQrsRivL46F',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::tr17lV9sCZtTjnnH' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/grado/actualizarGrados',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\GradoController@actualizarGrados',
        'controller' => 'App\\Http\\Controllers\\GradoController@actualizarGrados',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::tr17lV9sCZtTjnnH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::8x0OvfXQruuHM3eL' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/grado/getDetalleGrados',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\GradoController@getDetalleGrados',
        'controller' => 'App\\Http\\Controllers\\GradoController@getDetalleGrados',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::8x0OvfXQruuHM3eL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::dk6kgJ2VK9pk7tLW' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/listadinamica/getNombresListas',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\ListaDinamicaController@getNombresListas',
        'controller' => 'App\\Http\\Controllers\\ListaDinamicaController@getNombresListas',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::dk6kgJ2VK9pk7tLW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::wjPkv81pkkrNXkgc' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/listadinamica/crearNombresListas',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\ListaDinamicaController@crearNombresListas',
        'controller' => 'App\\Http\\Controllers\\ListaDinamicaController@crearNombresListas',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::wjPkv81pkkrNXkgc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Ub5hIRJb3OSKObOr' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/listadinamica/actualizarNombresListas',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\ListaDinamicaController@actualizarNombresListas',
        'controller' => 'App\\Http\\Controllers\\ListaDinamicaController@actualizarNombresListas',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::Ub5hIRJb3OSKObOr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Thlu5Vsfj2CV8njA' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/listadinamica/getListasDinamicas',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\ListaDinamicaController@getListasDinamicas',
        'controller' => 'App\\Http\\Controllers\\ListaDinamicaController@getListasDinamicas',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::Thlu5Vsfj2CV8njA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::acqjWDoPQVCUfSa9' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/listadinamica/crearListasDinamicas',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\ListaDinamicaController@crearListasDinamicas',
        'controller' => 'App\\Http\\Controllers\\ListaDinamicaController@crearListasDinamicas',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::acqjWDoPQVCUfSa9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::N70VSUAyXmuUvutj' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/listadinamica/actualizarListasDinamicas',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\ListaDinamicaController@actualizarListasDinamicas',
        'controller' => 'App\\Http\\Controllers\\ListaDinamicaController@actualizarListasDinamicas',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::N70VSUAyXmuUvutj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::G5gU3R52TjX0sC1o' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/listadinamica/getNombresListasFull',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\ListaDinamicaController@getNombresListasFull',
        'controller' => 'App\\Http\\Controllers\\ListaDinamicaController@getNombresListasFull',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::G5gU3R52TjX0sC1o',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::7ceaHib4stClA7OG' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/menu/getMenus',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\MenuController@getMenus',
        'controller' => 'App\\Http\\Controllers\\MenuController@getMenus',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::7ceaHib4stClA7OG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::TlDAIkJvOQfnnviV' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/menu/crearMenus',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\MenuController@crearMenus',
        'controller' => 'App\\Http\\Controllers\\MenuController@crearMenus',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::TlDAIkJvOQfnnviV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::fmgI4rIW1TmiQmA6' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/menu/actualizarMenus',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\MenuController@actualizarMenus',
        'controller' => 'App\\Http\\Controllers\\MenuController@actualizarMenus',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::fmgI4rIW1TmiQmA6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::80QW5qM4DAwq67rf' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/perfil/getPerfiles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\PerfilController@getPerfiles',
        'controller' => 'App\\Http\\Controllers\\PerfilController@getPerfiles',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::80QW5qM4DAwq67rf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::aTfz2IvuGK9qaltE' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/perfil/crearPerfiles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\PerfilController@crearPerfiles',
        'controller' => 'App\\Http\\Controllers\\PerfilController@crearPerfiles',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::aTfz2IvuGK9qaltE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::tPerGLRAH0jRk7uJ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/perfil/actualizarPerfiles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\PerfilController@actualizarPerfiles',
        'controller' => 'App\\Http\\Controllers\\PerfilController@actualizarPerfiles',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::tPerGLRAH0jRk7uJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::YYXKsjlh316TwKHn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/perfil/getPerfilesFull',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\PerfilController@getPerfilesFull',
        'controller' => 'App\\Http\\Controllers\\PerfilController@getPerfilesFull',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::YYXKsjlh316TwKHn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::vBaPnHkLMidwqEGN' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/perfilusuario/getPerfilesUsuarios',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\PerfilUsuarioController@getPerfilesUsuarios',
        'controller' => 'App\\Http\\Controllers\\PerfilUsuarioController@getPerfilesUsuarios',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::vBaPnHkLMidwqEGN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::KpCTHCRS3KyVAKb8' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/perfilusuario/crearPerfilesUsuario',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\PerfilUsuarioController@crearPerfilesUsuarios',
        'controller' => 'App\\Http\\Controllers\\PerfilUsuarioController@crearPerfilesUsuarios',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::KpCTHCRS3KyVAKb8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::yB3VjmgUe452Dz4X' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/perfilusuario/actualizarPerfilesUsuarios',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\PerfilUsuarioController@actualizarPerfilesUsuarios',
        'controller' => 'App\\Http\\Controllers\\PerfilUsuarioController@actualizarPerfilesUsuarios',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::yB3VjmgUe452Dz4X',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::F0mYUgUU3nxeySV9' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/requerimiento/getRequerimientos',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\RequerimientoController@getRequerimientos',
        'controller' => 'App\\Http\\Controllers\\RequerimientoController@getRequerimientos',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::F0mYUgUU3nxeySV9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::25Gg7ol4JnzgamCO' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/requerimiento/crearRequerimientos',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\RequerimientoController@crearRequerimientos',
        'controller' => 'App\\Http\\Controllers\\RequerimientoController@crearRequerimientos',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::25Gg7ol4JnzgamCO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::SXPpYA6T8uDnAON4' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/requerimiento/actualizarRequerimientos',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\RequerimientoController@actualizarRequerimientos',
        'controller' => 'App\\Http\\Controllers\\RequerimientoController@actualizarRequerimientos',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::SXPpYA6T8uDnAON4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::GlYu5XbSkBRWxAaX' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rutacarrera/getRutaCarrera',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\RutaCarreraController@getRutaCarrera',
        'controller' => 'App\\Http\\Controllers\\RutaCarreraController@getRutaCarrera',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::GlYu5XbSkBRWxAaX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::zFISJWb58raEAFDy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rutacarrera/crearRutaCarrera',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\RutaCarreraController@crearRutaCarrera',
        'controller' => 'App\\Http\\Controllers\\RutaCarreraController@crearRutaCarrera',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::zFISJWb58raEAFDy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::qgy534RkPqZuagdU' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rutacarrera/actualizarRutaCarrera',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\RutaCarreraController@actualizarRutaCarrera',
        'controller' => 'App\\Http\\Controllers\\RutaCarreraController@actualizarRutaCarrera',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::qgy534RkPqZuagdU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::t9eS5e4bSpaTuEkO' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rutacarrera/crearLineasCargos',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\RutaCarreraController@crearLineasCargos',
        'controller' => 'App\\Http\\Controllers\\RutaCarreraController@crearLineasCargos',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::t9eS5e4bSpaTuEkO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::51fTI4NXt9IFcid8' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rutacarrera/actualizarLineasCargos',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\RutaCarreraController@actualizarLineasCargos',
        'controller' => 'App\\Http\\Controllers\\RutaCarreraController@actualizarLineasCargos',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::51fTI4NXt9IFcid8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::lj1FcfjWKKnBDEw4' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rutacarrera/getLineasCargos',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\RutaCarreraController@getLineasCargos',
        'controller' => 'App\\Http\\Controllers\\RutaCarreraController@getLineasCargos',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::lj1FcfjWKKnBDEw4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::BFMpqxDqkhbVVLuE' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rutacarrera/getRutas',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\RutaCarreraController@getRutas',
        'controller' => 'App\\Http\\Controllers\\RutaCarreraController@getRutas',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::BFMpqxDqkhbVVLuE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::vQwVHbcExF60qX8a' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rutacarrera/crearRutas',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\RutaCarreraController@crearRutas',
        'controller' => 'App\\Http\\Controllers\\RutaCarreraController@crearRutas',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::vQwVHbcExF60qX8a',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::rVqjhF2fgDoBgCZX' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rutacarrera/actualizarRutas',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\RutaCarreraController@actualizarRutas',
        'controller' => 'App\\Http\\Controllers\\RutaCarreraController@actualizarRutas',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::rVqjhF2fgDoBgCZX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::OoJMzjIb6m5quXwO' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rutacarrera/getRutasByRutaCarrera',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\RutaCarreraController@getRutasByRutaCarrera',
        'controller' => 'App\\Http\\Controllers\\RutaCarreraController@getRutasByRutaCarrera',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::OoJMzjIb6m5quXwO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::EPXiX7CgXnoMW2uU' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rutacarrera/getCargosByRutas',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\RutaCarreraController@getCargosByRutas',
        'controller' => 'App\\Http\\Controllers\\RutaCarreraController@getCargosByRutas',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::EPXiX7CgXnoMW2uU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::bWO1Ucw3KJ9S47So' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rutacarrera/getGradosByEspecialidad',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\RutaCarreraController@getGradosByEspecialidad',
        'controller' => 'App\\Http\\Controllers\\RutaCarreraController@getGradosByEspecialidad',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::bWO1Ucw3KJ9S47So',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::EM8MmIeFkQOYLaVt' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rutacarrera/getGradosDetalleByEspecialidad',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\RutaCarreraController@getGradosDetalleByEspecialidad',
        'controller' => 'App\\Http\\Controllers\\RutaCarreraController@getGradosDetalleByEspecialidad',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::EM8MmIeFkQOYLaVt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ZUzHXZEtz2DhfDQJ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rutacarrera/getGradosDetalleCargo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\RutaCarreraController@getGradosDetalleCargo',
        'controller' => 'App\\Http\\Controllers\\RutaCarreraController@getGradosDetalleCargo',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::ZUzHXZEtz2DhfDQJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::2LWJJ0AlLCtChxaz' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rutacarrera/getGradosDetalleRequerimiento',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\RutaCarreraController@getGradosDetalleRequerimiento',
        'controller' => 'App\\Http\\Controllers\\RutaCarreraController@getGradosDetalleRequerimiento',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::2LWJJ0AlLCtChxaz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::iWkbs24llcgUTVW5' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rutacarrera/getCuerposByCategoria',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\RutaCarreraController@getCuerposByCategoria',
        'controller' => 'App\\Http\\Controllers\\RutaCarreraController@getCuerposByCategoria',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::iWkbs24llcgUTVW5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::LCwKIaWuKGqDVMWe' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rutacarrera/getEspecialidadesByCategoriaCuerpo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\RutaCarreraController@getEspecialidadesByCategoriaCuerpo',
        'controller' => 'App\\Http\\Controllers\\RutaCarreraController@getEspecialidadesByCategoriaCuerpo',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::LCwKIaWuKGqDVMWe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::HHuaHTGjwUfOnO1G' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rutacarrera/getAreasByCategoriaEspecialidad',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\RutaCarreraController@getAreasByCategoriaEspecialidad',
        'controller' => 'App\\Http\\Controllers\\RutaCarreraController@getAreasByCategoriaEspecialidad',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::HHuaHTGjwUfOnO1G',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::uSbVVvSBoyrH4MUQ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rutacarrera/getDetalleCargoRutaCarrera',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\RutaCarreraController@getDetalleCargoRutaCarrera',
        'controller' => 'App\\Http\\Controllers\\RutaCarreraController@getDetalleCargoRutaCarrera',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::uSbVVvSBoyrH4MUQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::zkib3TEsnnEROgPe' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/rutacarrera/getCuerposEspecialidadesAreasRutaCarrera',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\RutaCarreraController@getCuerposEspecialidadesAreasRutaCarrera',
        'controller' => 'App\\Http\\Controllers\\RutaCarreraController@getCuerposEspecialidadesAreasRutaCarrera',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::zkib3TEsnnEROgPe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::8AONqRSq2oUCGlmR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/rutacarrera/getEspecialidadesRutas',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\RutaCarreraController@getEspecialidadesRutas',
        'controller' => 'App\\Http\\Controllers\\RutaCarreraController@getEspecialidadesRutas',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::8AONqRSq2oUCGlmR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::rzBSNYm1Jd4hOYPm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/rutacarrera/getRutasFull',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\RutaCarreraController@getRutasFull',
        'controller' => 'App\\Http\\Controllers\\RutaCarreraController@getRutasFull',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::rzBSNYm1Jd4hOYPm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::0hKEYxuD9VhaFXc3' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/rutacarrera/getRutaCarreraActivos',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\RutaCarreraController@getRutaCarreraActivos',
        'controller' => 'App\\Http\\Controllers\\RutaCarreraController@getRutaCarreraActivos',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::0hKEYxuD9VhaFXc3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::yz8HGAxK9cxVarek' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rol/getRoles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\RolController@getRoles',
        'controller' => 'App\\Http\\Controllers\\RolController@getRoles',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::yz8HGAxK9cxVarek',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::iShrV9JhM1dtQJPL' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rol/crearRoles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\RolController@crearRoles',
        'controller' => 'App\\Http\\Controllers\\RolController@crearRoles',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::iShrV9JhM1dtQJPL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::uYwunL0yb5BqvJYE' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rol/actualizarRoles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\RolController@actualizarRoles',
        'controller' => 'App\\Http\\Controllers\\RolController@actualizarRoles',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::uYwunL0yb5BqvJYE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::hsi6KcirQBmx8T3p' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rol/crearRolPrivilegios',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\RolController@crearRolPrivilegios',
        'controller' => 'App\\Http\\Controllers\\RolController@crearRolPrivilegios',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::hsi6KcirQBmx8T3p',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::WMVv9H6aCU4Zt94K' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rol/actualizarRolPrivilegios',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\RolController@actualizarRolPrivilegios',
        'controller' => 'App\\Http\\Controllers\\RolController@actualizarRolPrivilegios',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::WMVv9H6aCU4Zt94K',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::SEw2BTVPK9qtj7e3' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rol/getRolPrivilegiosById',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\RolController@getRolPrivilegiosById',
        'controller' => 'App\\Http\\Controllers\\RolController@getRolPrivilegiosById',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::SEw2BTVPK9qtj7e3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::5JO1PlE75zQeYKg7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/rol/getRolesActivos',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\RolController@getRolesActivos',
        'controller' => 'App\\Http\\Controllers\\RolController@getRolesActivos',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::5JO1PlE75zQeYKg7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ibbAk9gKHSpk4pCv' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/rol/getModulos',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\RolController@getModulos',
        'controller' => 'App\\Http\\Controllers\\RolController@getModulos',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::ibbAk9gKHSpk4pCv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::IJLJuB3tc2ohO4Wx' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/usuario/getUsuariosFull',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\UsuarioController@getUsuariosFull',
        'controller' => 'App\\Http\\Controllers\\UsuarioController@getUsuariosFull',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::IJLJuB3tc2ohO4Wx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ehR31itZIEaFaYvm' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/usuario/getUsuarios',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\UsuarioController@getUsuarios',
        'controller' => 'App\\Http\\Controllers\\UsuarioController@getUsuarios',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::ehR31itZIEaFaYvm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::gTKXFh2p6IhyOlEg' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/usuario/crearUsuarios',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\UsuarioController@crearUsuarios',
        'controller' => 'App\\Http\\Controllers\\UsuarioController@crearUsuarios',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::gTKXFh2p6IhyOlEg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::797WeWR8JEkgtkXZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/usuario/actualizarUsuarios',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\UsuarioController@actualizarUsuarios',
        'controller' => 'App\\Http\\Controllers\\UsuarioController@actualizarUsuarios',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::797WeWR8JEkgtkXZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::rJedlermaexZFCfW' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/usuario/crearUsuarioRol',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\UsuarioController@crearUsuarioRol',
        'controller' => 'App\\Http\\Controllers\\UsuarioController@crearUsuarioRol',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::rJedlermaexZFCfW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::yEuCKsb3sFwMpMV6' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/usuario/actualizarUsuarioRol',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\UsuarioController@actualizarUsuarioRol',
        'controller' => 'App\\Http\\Controllers\\UsuarioController@actualizarUsuarioRol',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::yEuCKsb3sFwMpMV6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::GHAIrvp4lFVg4GmC' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/usuario/getUsuariosRolesById',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\UsuarioController@getUsuariosRolesById',
        'controller' => 'App\\Http\\Controllers\\UsuarioController@getUsuariosRolesById',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::GHAIrvp4lFVg4GmC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::x6T8b4hlz8ce6Pnk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/usuario/getRolPrivilegiosPantalla',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\UsuarioController@getRolPrivilegiosPantalla',
        'controller' => 'App\\Http\\Controllers\\UsuarioController@getRolPrivilegiosPantalla',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::x6T8b4hlz8ce6Pnk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::oBApDYepdQpFORWc' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/usuariomenu/crearUsuarioMenu',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\UsuarioMenuController@crearUsuarioMenu',
        'controller' => 'App\\Http\\Controllers\\UsuarioMenuController@crearUsuarioMenu',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::oBApDYepdQpFORWc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::qcgKMdnwm8V46qkG' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/usuariomenu/actualizarUsuarioMenu',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\UsuarioMenuController@actualizarUsuarioMenu',
        'controller' => 'App\\Http\\Controllers\\UsuarioMenuController@actualizarUsuarioMenu',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::qcgKMdnwm8V46qkG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::OKV4oBULshHOxnlT' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/usuariomenu/crearAsignarMenus',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\UsuarioMenuController@crearAsignarMenus',
        'controller' => 'App\\Http\\Controllers\\UsuarioMenuController@crearAsignarMenus',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::OKV4oBULshHOxnlT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::lwC9EanczfLmh8mW' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/usuariomenu/actualizarAsignarMenus',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'jwt.verify',
        ),
        'uses' => 'App\\Http\\Controllers\\UsuarioMenuController@actualizarAsignarMenus',
        'controller' => 'App\\Http\\Controllers\\UsuarioMenuController@actualizarAsignarMenus',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::lwC9EanczfLmh8mW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::rDMEaaOfeB2TNerU' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'C:32:"Opis\\Closure\\SerializableClosure":258:{@78yhdIrciVJ5OiWfwRcgb9aTA45GfwrkY+FlTRavyYg=.a:5:{s:3:"use";a:0:{}s:8:"function";s:46:"function () {
    return \\view(\'welcome\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000000a514d890000000014acfcc5";}}',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::rDMEaaOfeB2TNerU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
  ),
)
);
